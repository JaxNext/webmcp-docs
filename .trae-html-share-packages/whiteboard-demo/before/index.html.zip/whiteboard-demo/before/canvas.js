// canvas.js — the drawing surface.
//
// The element and its 2d context are looked up here and imported everywhere
// else, so there is exactly one place that queries the DOM for them.

export const canvas = document.querySelector('#board');
export const ctx = canvas.getContext('2d');
