// state.js — the whiteboard's data. No drawing, no DOM.
//
// `state` is one mutable object, so every module sees the same board.
// `draft` is reassigned on every stroke instead of mutated, and imported
// bindings are read-only, so it is exposed through accessors.

export const state = {
  tool: 'brush',        // brush | rect | ellipse | line | text
  color: '#1e88e5',
  width: 4,
  fill: false,
  items: [],            // drawn objects, oldest first
  undoStack: [],        // JSON snapshots for undo
};

let draft = null;

export const getDraft = () => draft;
export const setDraft = (next) => { draft = next; };

export function setBrush({ tool, color, width, fill }) {
  Object.assign(state, { tool, color, width, fill });
}

export function pushSnapshot() {
  state.undoStack.push(JSON.stringify(state.items));
}
