// render.js — paints the board. Read-only: it never mutates state.

import { canvas, ctx } from './canvas.js';
import { state, getDraft } from './state.js';

export function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (const item of state.items) drawItem(item);

  const draft = getDraft();
  if (draft) drawItem(draft);   // show the in-progress stroke on top
}

function drawItem(item) {
  ctx.strokeStyle = item.color;
  ctx.fillStyle = item.color;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  if (item.kind === 'path') {
    ctx.lineWidth = item.width;
    if (item.points.length === 1) {
      const [p] = item.points;                 // single click → dot
      ctx.beginPath();
      ctx.arc(p.x, p.y, item.width / 2, 0, Math.PI * 2);
      ctx.fill();
      return;
    }
    ctx.beginPath();
    ctx.moveTo(item.points[0].x, item.points[0].y);
    for (const p of item.points.slice(1)) ctx.lineTo(p.x, p.y);
    ctx.stroke();
  } else if (item.kind === 'shape') {
    ctx.lineWidth = item.strokeWidth;          // outline width captured at draw time
    ctx.beginPath();
    if (item.type === 'ellipse') {
      ctx.ellipse(item.x, item.y, Math.abs(item.width) / 2, Math.abs(item.height) / 2, 0, 0, Math.PI * 2);
    } else if (item.type === 'line') {
      ctx.moveTo(item.x, item.y);
      ctx.lineTo(item.x + item.width, item.y + item.height);
    } else { // rect
      ctx.rect(item.x, item.y, item.width, item.height);
    }
    if (item.type === 'line') ctx.stroke();
    else if (item.fill) ctx.fill();
    else ctx.stroke();
  } else if (item.kind === 'text') {
    ctx.font = '20px system-ui, sans-serif';
    ctx.fillText(item.text, item.x, item.y);
  }
}
