// commands.js — every operation the board can perform.
//
// This is the app's public surface: the toolbar calls these today, and the
// WebMCP tools will call exactly these later. One function per user action,
// each one snapshotting for undo and re-rendering.

import { canvas } from './canvas.js';
import { state, pushSnapshot } from './state.js';
import { render } from './render.js';

export function drawShape({ type, x = 0, y = 0, width = 80, height = 80, color = state.color }) {
  pushSnapshot();
  state.items.push({ kind: 'shape', type, x, y, width, height, color, fill: state.fill, strokeWidth: state.width });
  render();
}

export function drawPath(points, { color = state.color, width = state.width } = {}) {
  pushSnapshot();
  state.items.push({ kind: 'path', points, color, width });
  render();
}

export function addText(text, x = 0, y = 0, color = state.color) {
  pushSnapshot();
  state.items.push({ kind: 'text', text, x, y, color });
  render();
}

export function undo() {
  const prev = state.undoStack.pop();
  if (prev != null) {
    state.items = JSON.parse(prev);
    render();
  }
}

export function clearCanvas() {
  pushSnapshot();
  state.items = [];
  render();
}

export function getCanvasState() {
  return {
    shapeCount: state.items.length,
    items: state.items.map(({ kind, type, text, x, y, color, points }) => ({
      kind,
      type,
      text,
      x,
      y,
      color,
      pointCount: points ? points.length : undefined,
    })),
  };
}

export function exportPng() {
  const a = document.createElement('a');
  a.href = canvas.toDataURL('image/png');
  a.download = 'whiteboard.png';
  a.click();
}
