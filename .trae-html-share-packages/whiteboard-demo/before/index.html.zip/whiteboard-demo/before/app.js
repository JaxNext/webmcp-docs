// app.js — entry point.
//
// Importing input.js registers the pointer and palette listeners; after that
// the board runs by itself. Only the initial paint is explicit.

import { syncBrush } from './input.js';
import { render } from './render.js';

syncBrush();
render();
