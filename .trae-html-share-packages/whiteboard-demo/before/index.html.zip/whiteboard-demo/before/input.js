// input.js — human input: pointer strokes on the canvas, plus the palette and
// toolbar controls. Everything the user does lands here and is turned into a
// command.

import { canvas } from './canvas.js';
import { state, setBrush, getDraft, setDraft } from './state.js';
import { render } from './render.js';
import { addText, clearCanvas, drawPath, drawShape, exportPng, undo } from './commands.js';

const status = document.querySelector('#status');

function toLocal(e) {
  const rect = canvas.getBoundingClientRect();
  // Scale client coordinates into the canvas's internal pixel grid, so drawing
  // stays correct even when CSS resizes the element.
  return {
    x: (e.clientX - rect.left) * (canvas.width / rect.width),
    y: (e.clientY - rect.top) * (canvas.height / rect.height),
  };
}

canvas.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  canvas.setPointerCapture(e.pointerId);
  const { x, y } = toLocal(e);

  if (state.tool === 'text') {
    const text = prompt('Text to add:');   // a nicer inline editor can replace this
    if (text) addText(text, x, y);
    return;
  }

  if (state.tool === 'brush') {
    setDraft({ kind: 'path', points: [{ x, y }], color: state.color, width: state.width });
  } else {
    setDraft({ kind: 'shape', type: state.tool, x, y, width: 0, height: 0, color: state.color, fill: state.fill, strokeWidth: state.width });
  }
  render();
});

canvas.addEventListener('pointermove', (e) => {
  const draft = getDraft();
  if (!draft) return;
  const { x, y } = toLocal(e);
  if (draft.kind === 'path') {
    draft.points.push({ x, y });
  } else {
    draft.width = x - draft.x;
    draft.height = y - draft.y;
  }
  render();
});

canvas.addEventListener('pointerup', () => {
  const draft = getDraft();
  if (!draft) return;
  setDraft(null);   // clear before drawing, so the stroke isn't painted twice

  if (draft.kind === 'path') {
    drawPath(draft.points, { color: draft.color, width: draft.width });
  } else {
    drawShape({ type: draft.type, x: draft.x, y: draft.y, width: draft.width, height: draft.height, color: draft.color });
  }
});

canvas.addEventListener('pointercancel', () => {
  setDraft(null);
  render();
});

// --- Palette + toolbar ------------------------------------------------------

const colorInput = document.querySelector('#brush-color');
const widthInput = document.querySelector('#brush-width');
const toolSelect = document.querySelector('#brush-tool');
const fillInput = document.querySelector('#brush-fill');

export function syncBrush() {
  setBrush({
    color: colorInput.value,
    width: Number(widthInput.value),
    tool: toolSelect.value,
    fill: fillInput.checked,
  });
  status.textContent = `Tool: ${state.tool} · Color: ${state.color} · Width: ${state.width}px`;
}

colorInput.addEventListener('input', syncBrush);
widthInput.addEventListener('input', syncBrush);
toolSelect.addEventListener('change', syncBrush);
fillInput.addEventListener('change', syncBrush);

document.querySelector('#undo-btn').addEventListener('click', () => {
  undo();
  status.textContent = 'Undid last action.';
});

document.querySelector('#clear-btn').addEventListener('click', () => {
  clearCanvas();
  status.textContent = 'Cleared whiteboard.';
});

document.querySelector('#export-btn').addEventListener('click', () => {
  exportPng();
  status.textContent = 'Exported PNG.';
});
